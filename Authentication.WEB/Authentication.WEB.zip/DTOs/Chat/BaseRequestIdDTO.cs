﻿namespace InsuredTraveling.DTOs
{
    public class BaseRequestIdDTO
    {
        public int RequestId { get; set; }
    }
}