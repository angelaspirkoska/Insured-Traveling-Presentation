﻿namespace InsuredTraveling.DTOs
{
    public class RequestDTO 
    {
        public string RequestedBy { get; set; }
        public string Timestamp { get; set; }
    }
}