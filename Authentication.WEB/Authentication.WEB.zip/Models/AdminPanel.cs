﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsuredTraveling.Models
{
   
    public class AdminPanel
    {
        public class Roles
        {
            public string Name { get; set; }
            public int Id { get; set; }
            public string UserID { get; set; }

        }

    }
}