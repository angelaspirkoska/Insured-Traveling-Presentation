﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsuredTraveling.Models
{
    public class DiscountCodeValidateModel
    {
        public string DiscCode { get; set; }
    }
}