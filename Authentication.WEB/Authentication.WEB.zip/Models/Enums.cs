﻿namespace InsuredTraveling.Models
{
    public class Enums
    {
        public enum ApplicationTypes
        {
            JavaScript = 0,
            NativeConfidential = 1
        };

        //public enum PolicyType
        //{
        //    Comfort = 1,
        //    Normal = 2,
        //    Visa = 3,
        //    VisaGr = 4,
        //    VisaSosedi = 5
        //};
    }

}