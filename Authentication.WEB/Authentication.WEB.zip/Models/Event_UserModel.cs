﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsuredTraveling.Models
{
    public class Event_UserModel
    {
       public int id { get; set; }
        public int EventID { get; set; }
        public string UserID { get; set; }
    }
}