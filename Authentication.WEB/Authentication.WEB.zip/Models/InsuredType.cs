﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsuredTraveling.Models
{
    public class InsuredType
    {
        public enum Type
        {
            insured = 0,
            additional_insured = 1
        };
    }
}