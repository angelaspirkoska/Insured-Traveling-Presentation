﻿namespace InsuredTraveling.Models
{
    public class News
    {
        public string id { get; set; }
        public string title { get; set; }
        public string content { get; set; }
        public string InsuranceCompany { get; set; }

    }
}
