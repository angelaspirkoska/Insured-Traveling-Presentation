﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsuredTraveling.Models
{
    public class OK_SETUP
    {
        public string InsuranceCompany { get; set; }
        public int? Version { get; set; }
    }
}