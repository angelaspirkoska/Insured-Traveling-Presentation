﻿namespace Authentication.WEB.Models
{
    public class PaymentFailModel
    {
        public string ErrMsg { get; set; }
        public string mdErrorMsg { get; set; }
    }
}
