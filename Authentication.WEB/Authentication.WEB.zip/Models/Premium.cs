﻿namespace Authentication.WEB.Models
{
    public class Premium
    {
            public int PremiumAmount { get; set; }
    }
}
