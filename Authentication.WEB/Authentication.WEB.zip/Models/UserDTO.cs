﻿using System;

namespace InsuredTraveling.Models
{
    public class UserDTO
    {
        public String username { get; set; }

        public String ID { get; set; }

        public String email { get; set; }

        public string code { get; set; }
    }
}