﻿namespace InsuredTraveling.Models
{
    public class ValidationModel
    {
        public string ID { get; set; }
        public string ActivationCode { get; set; }
    }
}
